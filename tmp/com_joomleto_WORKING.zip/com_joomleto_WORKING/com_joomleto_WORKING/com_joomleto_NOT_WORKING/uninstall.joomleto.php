<?php
function com_uninstall() {
  echo "Obrigado por usar esse componente. Qualquer duvida contate suporte@focalizaisso.com.br";
}
?>


