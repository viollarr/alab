function hideLoading() {
	document.getElementById('loading').style.display = 'none'; // DOM3 (IE5, NS6) only
}