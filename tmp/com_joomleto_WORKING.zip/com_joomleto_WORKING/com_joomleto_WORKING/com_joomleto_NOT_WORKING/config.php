<?php

// SEUS DADOS
$dadosboleto["identificacao"]   = "Focalizar.com.br - Sua Empresa em evid�ncia";
$dadosboleto["cpf_cnpj"]        = "08.217.369/0001-62";
$dadosboleto["endereco"]        = "Servi�os de Publicidade na Internet:";
$dadosboleto["cidade_uf"]       = "Listas de telefones, Lista de Im�veis, Classificados e muito mais!";
$dadosboleto["cedente"]         = "Focalizar Servi�os de Publicidade na Internet Ltda.";

//Cron Job config



$comTemplate	= $pathCom.'templates/default';
$defaultState   = '24';    // 24 = Santa Catarina
$defaultCity    = '8278';    // 8278 = Joinville replace with '0' for no selected city

?>
